package beer.unacceptable.unacceptablehealth.Controllers;

import java.util.Date;

//TODO: Obsolete. Use ITimeSource in the Library
public interface IDateLogic {
    public Date getTodaysDate();
}
