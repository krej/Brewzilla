package beer.unacceptable.unacceptablehealth.Models.CustomReturns;

import java.util.ArrayList;

import beer.unacceptable.unacceptablehealth.Models.Exercise;
import beer.unacceptable.unacceptablehealth.Models.WorkoutPlan;
import beer.unacceptable.unacceptablehealth.Models.WorkoutType;

public class WorkoutPlanWithExtras {
    public WorkoutPlan WorkoutPlan;
    public Exercise[] Exercises;
    public WorkoutType[] WorkoutTypes;
}
