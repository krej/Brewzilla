package beer.unacceptable.unacceptablehealth.Screens;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import beer.unacceptable.unacceptablehealth.R;

public class GPXTest extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_g_p_x_test);
    }
}