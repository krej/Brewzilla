package beer.unacceptable.unacceptablehealth.Models.CustomReturns;

import beer.unacceptable.unacceptablehealth.Models.WorkoutPlan;

public class WorkoutPlanList {
    public WorkoutPlan[] WorkoutPlans;
}
