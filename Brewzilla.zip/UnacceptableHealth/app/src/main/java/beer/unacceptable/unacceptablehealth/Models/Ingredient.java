package beer.unacceptable.unacceptablehealth.Models;

import com.unacceptable.unacceptablelibrary.Models.ListableObject;

/**
 * Theres nothing really to this class. It is just a name, which exists in ListableObject. I just wanted a class called Ingredient.
 */
public class Ingredient extends ListableObject {
    public Ingredient(String name) {
        this.name = name;
    }
}
