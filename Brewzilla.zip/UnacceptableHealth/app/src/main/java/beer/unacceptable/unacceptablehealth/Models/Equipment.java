package beer.unacceptable.unacceptablehealth.Models;

import com.unacceptable.unacceptablelibrary.Models.ListableObject;

public class Equipment extends ListableObject {
}
