package beer.unacceptable.unacceptablehealth.Models.CustomReturns;

import beer.unacceptable.unacceptablehealth.Models.GoalItem;
import beer.unacceptable.unacceptablehealth.Models.WorkoutPlan;

public class GoalItemsWithWorkoutPlans {
    public GoalItem[] GoalItems;
    public WorkoutPlan[] WorkoutPlans;
}
