package beer.unacceptable.unacceptablehealth.Models;

import com.google.gson.annotations.Expose;

public class CalorieLog {
    @Expose
    Equipment Equipment;
    @Expose
    int Calories;
}
