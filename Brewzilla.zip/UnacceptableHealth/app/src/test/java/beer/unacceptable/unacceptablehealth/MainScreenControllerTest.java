package beer.unacceptable.unacceptablehealth;

import com.android.volley.VolleyError;
import com.unacceptable.unacceptablelibrary.Adapters.NewAdapter;
import com.unacceptable.unacceptablelibrary.Repositories.RepositoryCallback;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

import beer.unacceptable.unacceptablehealth.Controllers.IDateLogic;
import beer.unacceptable.unacceptablehealth.Controllers.MainScreenController;
import beer.unacceptable.unacceptablehealth.Models.DailyLog;
import beer.unacceptable.unacceptablehealth.Models.GoalItem;
import beer.unacceptable.unacceptablehealth.Models.GoalItemAction;
import beer.unacceptable.unacceptablehealth.Models.WorkoutPlan;
import beer.unacceptable.unacceptablehealth.Models.WorkoutType;
import beer.unacceptable.unacceptablehealth.Repositories.IRepository;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class MainScreenControllerTest {
    private MainScreenController m_oController;
    private IRepository m_repo;
    private MainScreenController.View view;
    private IDateLogic m_date;

    @Before
    public void setup() {
        m_repo = mock(IRepository.class);
        view = mock(MainScreenController.View.class);
        m_date = mock(IDateLogic.class);
        m_oController = new MainScreenController(m_repo, m_date);
        m_oController.attachView(view);


        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                return getHardCodedDate();
            }
        }).when(m_date).getTodaysDate();
    }

    private Date getHardCodedDate() {
        Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.MONTH, Calendar.FEBRUARY); //changed to Calendar.FEBRUARY because its off by one
        calendar.set(Calendar.DAY_OF_MONTH, 22);
        calendar.set(Calendar.YEAR, 2019);
        calendar.set(Calendar.HOUR_OF_DAY, 7); //hard code an actual time because thats what new Date() returns when you run the program
        calendar.set(Calendar.MINUTE, 36);
        calendar.set(Calendar.SECOND, 24);
        calendar.set(Calendar.MILLISECOND, 0);
        Date dt = calendar.getTime();
        return dt;
    }

    @Test
    public void screenLoads_NoDailyLogStarted_NewLogButtonShows() {

        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                RepositoryCallback callback = invocation.getArgument(1);
                callback.onSuccess("{\n" +
                        "    \"Success\": true,\n" +
                        "    \"Message\": \"Log does not exist.\"\n" +
                        "}");
                return null;
            }
        }).when(m_repo).LoadDailyLogByDate(eq("02/22/2019"), any(RepositoryCallback.class));

        m_oController.LoadTodaysLog();

        verify(m_repo).LoadDailyLogByDate(eq("02/22/2019"), any(RepositoryCallback.class));
        verify(view).showTodaysLog(false);
        verify(view).showNewLogButton(true);
        verify(view, never()).populateTodaysLog(any(DailyLog.class));
    }

    @Test
    public void screenLoads_DailyLogStarted_ShowAndPopulateLogView() {

        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                RepositoryCallback callback = invocation.getArgument(1);
                callback.onSuccess("{\n" +
                        "    \"Id\": \"5c6380fe32856d03e41570db\",\n" +
                        "    \"idString\": \"5c6380fe32856d03e41570db\",\n" +
                        "    \"name\": \"02/12/2019\",\n" +
                        "    \"date\": \"2019-02-12T12:00:00Z\",\n" +
                        "    \"HealthRating\": 0,\n" +
                        "    \"BBD\": false,\n" +
                        "    \"UsedFlonase\": false,\n" +
                        "    \"FlonaseReasoning\": 0,\n" +
                        "    \"HadHeadache\": false,\n" +
                        "    \"WorkDay\": false,\n" +
                        "    \"WorkRating\": 0,\n" +
                        "    \"PersonalDayRating\": 0,\n" +
                        "    \"MindfulMoment\": \"isn't it an issue with apostle?\",\n" +
                        "    \"OverallNotes\": \"\"\n" +
                        "}");
                return null;
            }
        }).when(m_repo).LoadDailyLogByDate(eq("02/22/2019"), any(RepositoryCallback.class));

        m_oController.LoadTodaysLog();

        verify(m_repo).LoadDailyLogByDate(eq("02/22/2019"), any(RepositoryCallback.class));
        verify(view).showTodaysLog(true);
        verify(view).showNewLogButton(false);
        verify(view).populateTodaysLog(any(DailyLog.class));
    }

    @Test
    public void screenLods_FailureLoadingDailyLog_ShowError() {
        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                RepositoryCallback callback = invocation.getArgument(1);
                callback.onError(new VolleyError());
                return null;
            }
        }).when(m_repo).LoadDailyLogByDate(anyString(), any(RepositoryCallback.class));

        m_oController.LoadTodaysLog();

        verify(view).showNewLogButton(false);
        verify(view).showTodaysLog(false);
        verify(view).showDailyLogError();
    }

    @Test
    public void screenLoads_LoadTodaysGoalItems_SuccessPopulatesScreen() {

    }

    @Test
    public void setGoalCompleted_APIRespondsWithFailure_ShowToast() {
        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                RepositoryCallback callback = invocation.getArgument(1);
                //callback.onError(new VolleyError("{\"Success\":false,\"Message\":\"No GoalItems Completed\"}"));
                callback.onSuccess("{\"Success\":false,\"Message\":\"No GoalItems Completed\"}");
                return null;
            }
        }).when(m_repo).ModifyGoalItem(any(GoalItemAction.class), any(RepositoryCallback.class));

        WorkoutType workoutType = new WorkoutType();
        workoutType.name = "Arms";

        GoalItem goalItem = new GoalItem();
        goalItem.Completed = false;
        goalItem.WorkoutType = workoutType;
        goalItem.Date = getHardCodedDate();

        m_oController.ToggleGoalItemComplete(goalItem, null);

        verify(view).showToast(eq("No GoalItems Completed"));
    }

    @Test
    public void SortWorkoutPlansByLastUsed() {
        WorkoutPlan[] plans = new WorkoutPlan[2];
        WorkoutPlan w1 = new WorkoutPlan();
        w1.LastUsed = new Date(2020,9,11);
        w1.name = "One";
        plans[1] = w1;
        WorkoutPlan w0 = new WorkoutPlan();
        w0.LastUsed = new Date(2019,2,3);
        plans[0] = w0;
        w0.name = "Zero";

        Arrays.sort(plans, Comparator.comparing(WorkoutPlan::GetLastUsedAsInt));

        Assert.assertEquals("One", plans[0].name);
    }
}
