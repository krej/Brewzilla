package com.unacceptable.unacceptablelibrary.Tools.RecyclerViewSwipe;

import androidx.recyclerview.widget.RecyclerView;

public interface OnStartDragListener {
    void onStartDrag(RecyclerView.ViewHolder viewHolder);
}
